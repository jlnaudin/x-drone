Calmato Alpha (Kyosho) model for X-Plane
========================================
For non-commercial, private use only.  For RC training purpose and UAV developpement (tested on X-Plane v9.70).

Installation:
Copy the entire folder 'Calmato' into the x-Plane folder/Aircraft/Radio Control/

(c) 2013 by Jean-Louis Naudin all right reserved

More infos at: http://diydrones.com/profile/JeanLouisNaudin

Experimental researches and developpement of autopilots for aerial plateforms on Arduino boards (ArduPilot Mega v1.5, v2.x and Arduflyer v2.x)

Tests flights videos at: http://vimeo.com/user5037815/videos

AP Sources codes: https://github.com/jlnaudin/x-drone
