MaxiSwift (MS Composit) model for X-Plane
=========================================
(c) 2013 by Jean-Louis Naudin all right reserved

For non-commercial, private use only.  For RC training purpose and UAV developpement (tested on X-Plane v9.70).

Installation:
Copy the entire folder 'MaxiSwift' into the x-Plane folder/Aircraft/Radio Control/

More infos at: http://diydrones.com/profile/JeanLouisNaudin

Experimental researches and developpement of autopilots for aerial plateforms on Arduino boards (ArduPilot Mega v1.5, v2.x and Arduflyer v2.x)

Real tests flights videos at: http://player.vimeo.com/video/81333614

AP Sources codes: https://github.com/jlnaudin/x-drone
